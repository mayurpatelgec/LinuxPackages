export CVSROOT=:pserver:bugzilla:start@bugzilla:/SOURCE
#cvs login password "start"
mkdir SOURCE
cd SOURCE

cat ../filelist.txt | while read f; do
  cvs -q checkout -P $f
done

cd ..
